

function attachEvents() {
    document.getElementById('btnLoadPosts').addEventListener('click', loadPosts);
    
    document.getElementById('btnViewPost').addEventListener('click', viewPost);
}
async function loadPosts(event){

    let response = await fetch('http://localhost:3030/jsonstore/blog/posts');
    let postData =  await response.json();
    let postBody = document.getElementById('posts');
    postBody.innerHTML = '';  
     Object.entries(postData).forEach(([key, value])=>{
        let optionElement = document.createElement('option');
        optionElement.value = key;
        optionElement.textContent = value.title;
        postBody.appendChild(optionElement);
     });
     return postData;
};

async function viewPost(event){
    let response = await fetch('http://localhost:3030/jsonstore/blog/comments');
    let viewData =  await response.json();
    let id = document.getElementById('posts').value;
    let postData = await loadPosts();

    document.getElementById('post-title').textContent = postData[id].title;
    document.getElementById('post-body').textContent = postData[id].body;

    let listToAdd = document.getElementById('post-comments')
    listToAdd.innerHTML = '';
    console.log(Object.values(viewData));
    let comments = Object.values(viewData).filter(value => value.postId === id);
    Object.entries(comments).forEach(([key, value])=>{
        listToAdd.innerHTML+=`<li id="${value.id}">${value.text}</li>`
    });
};

attachEvents();